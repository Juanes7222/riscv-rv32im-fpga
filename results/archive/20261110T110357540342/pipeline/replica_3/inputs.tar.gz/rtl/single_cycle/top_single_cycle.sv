module top_single_cycle #(
    parameter int IMEM_DEPTH = 16384,
    parameter int DMEM_DEPTH = 8192,
    parameter logic [31:0] TOHOST_ADDR = 32'h708  // riscv-tests tohost symbol address
)(
    input logic clk,     // 50 MHz - DE1-SoC PIN_AF14 (CPU runs at 40 MHz, ADR 049)
    input logic rst_n,    // Active-low synchronous reset - KEY[0]
    input logic key_step, // KEY[1] raw pin, active low: 0 while pressed
    input logic key_load, // KEY[2] raw pin, active low: 0 while pressed (program load)
    input logic [3:0] sw, // SW[0:3]: program selector for the loader
    input logic step_mode,// SW[9], active high: freezes the processor
    output logic [9:0] ledr,       // pc[9:0]
    output logic [6:0] seven_seg_display0, // Connect to your 7-segment display output
    output logic [6:0] seven_seg_display1,
    output logic [6:0] seven_seg_display2,
    output logic [6:0] seven_seg_display3,
    output logic [6:0] seven_seg_display4,
    output logic [6:0] seven_seg_display5,

    // VGA output (Objective 4)
    output logic       vga_hsync,
    output logic       vga_vsync,
    output logic [7:0] vga_r,
    output logic [7:0] vga_g,
    output logic [7:0] vga_b,
    output logic       vga_clock,
    output logic       vga_blank_n,
    output logic       vga_sync_n
);

    localparam [4:0] ALU_DIV  = 5'b01110;
    localparam [4:0] ALU_DIVU = 5'b01111;
    localparam [4:0] ALU_REM  = 5'b10000;
    localparam [4:0] ALU_REMU = 5'b10001;

    localparam [1:0] ALUA_RS1  = 2'b00;
    localparam [1:0] ALUA_PC   = 2'b01;
    localparam [1:0] ALUA_ZERO = 2'b10;

    localparam [1:0] WB_ALU = 2'b00;
    localparam [1:0] WB_MEM = 2'b01;
    localparam [1:0] WB_PC4 = 2'b10;
    localparam [1:0] WB_CSR = 2'b11;    // ADR 027

    // Processor clock: 40 MHz from the 50 MHz oscillator.  The measured Fmax
    // of this microarchitecture is 46.17 MHz (the multiply writeback, ADR
    // 050), so CLOCK_50 would leave no margin (ADR 049).  The VGA pixel PLL
    // below keeps taking the 50 MHz pin.
    logic clk_cpu;
    logic cpu_pll_locked;

    // The CPU starts only once the PLL is locked: KEY[0] is a synchronous
    // reset, so a power-up that skips the button would otherwise run the
    // processor on an unlocked clock.
    logic rst_n_cpu;
    assign rst_n_cpu = rst_n & cpu_pll_locked;

    cpu_pll u_cpu_pll (
        .clk_in  (clk),
        .rst_in  (~rst_n),
        .clk_out (clk_cpu),
        .locked  (cpu_pll_locked)
    );


    // Fetch
    logic [31:0] pc;
    logic [31:0] pc_plus4;
    logic [31:0] next_pc;
    logic [31:0] imem_addr;
    logic [31:0] imem_instruction;
    logic [31:0] instruction;
    logic        fetch_valid;

    // Instruction fields
    logic [6:0]  opcode;
    logic [4:0]  rd_addr;
    logic [2:0]  funct3;
    logic [4:0]  rs1_addr;
    logic [4:0]  rs2_addr;
    logic [6:0]  funct7;
    logic [11:0] instr_31_20;   // ADR 027: CSR address / ECALL funct12

    // Control signals
    logic        ru_wr;
    logic [2:0]  imm_src;
    logic [1:0]  alua_src;
    logic        alub_src;
    logic [4:0]  alu_op;
    logic [4:0]  br_op;
    logic        dm_wr;
    logic [2:0]  dm_ctrl;
    logic [1:0]  ru_data_wr_src;

    // ADR 027: Trap / CSR control signals
    logic        trap_entry;
    logic        mret_exec;
    logic [11:0] csr_addr;
    logic        csr_wr_raw;
    logic        csr_wr;
    logic [1:0]  csr_op;
    logic        csr_imm;
    logic [31:0] csr_rdata;
    logic [31:0] csr_wdata;
    logic [31:0] trap_target;
    logic [31:0] mepc_value;

    // Register file
    logic [31:0] rs1_data;
    logic [31:0] rs2_data;
    logic [31:0] rd_data;
    logic [1023:0] rf_dbg_regs;   // whole register file, for the VGA console

    // Immediate
    logic [31:0] imm_out;

    // ALU
    logic [31:0] alu_a;
    logic [31:0] alu_b;
    logic [31:0] alu_res;
    logic [31:0] alu_sum;   // adder result, free of the multiplier
    logic        div_busy;
    logic        div_done;

    // Branch
    logic        branch;
    logic        mask_pc_lsb;

    // Memory
    logic [31:0] dm_rd_data;
    // Expose data-memory bus signals for cocotb monitor (flat names expected)
    // Protect from synthesis trimming - cocotb accesses these via hierarchical refs
    logic [31:0] dm_addr /* synthesis keep */;
    logic [31:0] dm_wdata /* synthesis keep */;

    // Alias internal signals to expected top-level names
    assign dm_addr  = alu_sum;
    assign dm_wdata = rs2_data;

    // Write-enable gate (ADR 023)
    logic        is_div;
    logic        wr_en_gated;


    assign opcode      = instruction[6:0];
    assign rd_addr     = instruction[11:7];
    assign funct3      = instruction[14:12];
    assign rs1_addr    = instruction[19:15];
    assign rs2_addr    = instruction[24:20];
    assign funct7      = instruction[31:25];
    assign instr_31_20 = instruction[31:20];

    // Write-enable gate for division
    assign is_div = (alu_op == ALU_DIV || alu_op == ALU_DIVU ||
                        alu_op == ALU_REM || alu_op == ALU_REMU);
    assign wr_en_gated = ru_wr & (~is_div | div_done);

     assign ledr = pc[9:0];

    always_comb begin
        case (alua_src)
            ALUA_RS1:  alu_a = rs1_data;
            ALUA_PC:   alu_a = pc;
            ALUA_ZERO: alu_a = 32'b0;
            default:   alu_a = rs1_data;
        endcase
    end

    assign alu_b = alub_src ? imm_out : rs2_data;

    // ADR 027: CSR write data mux - rs1_data vs zimm for immediate forms
    assign csr_wdata = csr_imm ? {27'b0, instruction[19:15]} : rs1_data;

    // ADR 027: Gate csr_wr for CSRRS/CSRRC with rs1 == x0 (read-only per spec)
    // CSRRS = funct3[2:0] == 3'b010, CSRRC = funct3[2:0] == 3'b011
    // For these, if rs1 == 0, the CSR is not written.
    assign csr_wr = csr_wr_raw &
                    ~( (funct3 == 3'b010 || funct3 == 3'b011) &&
                        (rs1_addr == 5'b0) );

    // ADR 027: rd_data mux - adds WB_CSR path, removes hardcoded OP_SYSTEM=0
    always_comb begin
        case (ru_data_wr_src)
            WB_ALU:  rd_data = alu_res;
            WB_MEM:  rd_data = dm_rd_data;
            WB_PC4:  rd_data = pc_plus4;
            WB_CSR:  rd_data = csr_rdata;
            default: rd_data = alu_res;
        endcase
    end

    logic [63:0] cycle_count;
    logic [63:0] instr_retired;
    logic [63:0] cycles_at_done;
    logic [63:0] instr_at_done;
    logic        program_done;

    // Any nonzero tohost value ends measurement, including failure codes.
    // The completing store is included in both counters.
    logic program_done_pulse;
    assign program_done_pulse = fetch_valid && !div_busy && !step_hold_effective
                             && dm_wr && (alu_sum == TOHOST_ADDR)
                             && (rs2_data != 32'd0);

    // Registered copy for the console and the SignalTap II trigger.
    always_ff @(posedge clk_cpu) begin
        if (!rst_n_cpu) begin
            program_done <= 1'b0;
        end else if (program_done_pulse) begin
            program_done <= 1'b1;
        end
    end

// synthesis translate_off
`ifndef SYNTHESIS
    // The waveform dump is disabled by default: a long benchmark run
    // writes gigabytes and becomes I/O bound.  Compile with -DDUMP_VCD
    // when the waveform is needed.
    `ifndef NO_VCD
    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0, top_single_cycle);
    end
    `endif
`endif
// synthesis translate_on

    // Step mode: SW[9] freezes the processor, KEY[1] releases it for one
    // cycle.  The freeze is applied to the write enables and to the PC,
    // never to the clock itself.  The data-memory write is left alone on
    // purpose: a re-executed store writes the same value to the same
    // address, so it is idempotent.  The console shadow shares that
    // write, and gating it alone would break the mirror.
    logic step_hold;

    // Power-on pause: hold the processor for a few cycles after reset releases,
    // so the initial state (PC=0, first instruction fetch) is visible on the
    // console before execution begins.  Independent of step_mode/SW[9].
    // In simulation (`SIMULATION`, defined for iverilog by the CPU PLL
    // model) there is no VGA console to warm up: the PC starts
    // immediately after the reset is released, as the single-step tests
    // (cocotb) expect.  In Quartus synthesis SIMULATION is not defined and
    // the pause is kept.
    `ifdef SIMULATION
        assign step_hold_effective = step_hold;
    `else
        logic [3:0] power_on_pause_cnt;
        logic       power_on_pause;

        always_ff @(posedge clk_cpu) begin
            if (!rst_n_cpu)
                power_on_pause_cnt <= 4'd0;
            else if (power_on_pause_cnt != 4'd15)
                power_on_pause_cnt <= power_on_pause_cnt + 4'd1;
        end

        assign power_on_pause = (power_on_pause_cnt < 4'd4);
        assign step_hold_effective = step_hold | power_on_pause;
    `endif

    step_mode_ctrl u_step_mode (
        .clk       (clk_cpu),
        .rst_n     (rst_n_cpu),
        .key_step  (key_step),
        .step_mode (step_mode),
        .step_hold (step_hold)
    );

    perf_counters #(
        .PIPELINE_MODE (1'b0)
    ) u_perf (
        .clk                  (clk_cpu),
        .rst_n                (rst_n_cpu),
        .enable               (~step_hold_effective & fetch_valid),
        .div_busy             (div_busy),
        .valid_wb             (1'b0),
        .program_done_pulse   (program_done_pulse),
        .cycle_count          (cycle_count),
        .instr_retired        (instr_retired),
        .program_done_synced  (),
        .cycles_at_done       (cycles_at_done),
        .instr_at_done        (instr_at_done)
    );

    pc u_pc (
        .clk         (clk_cpu),
        .rst_n       (rst_n_cpu),
        .branch      (branch),
        .mask_pc_lsb (mask_pc_lsb),
        .alu_res     (alu_res),
        .div_busy    (div_busy),
        .trap_entry  (trap_entry),
        .mret_exec   (mret_exec),
        .trap_target (trap_target),
        .mepc_value  (mepc_value),
        .step_hold   (step_hold_effective),
        .fetch_valid (fetch_valid),
        .pc          (pc),
        .pc_plus4    (pc_plus4),
        .next_pc     (next_pc)
    );

    // One fill cycle after reset: the instruction memory has no captured
    // address yet, so the processor holds the reset vector and executes a
    // NOP.  The cycle is excluded from the performance counters, so the
    // CPI=1 invariant keeps its meaning.  fetch_valid also waits for the
    // freeze to lift, so the fetch is not captured during the power-on pause
    // (which would skip the instruction at the reset vector).
    always_ff @(posedge clk_cpu) begin
        if (!rst_n_cpu)                fetch_valid <= 1'b0;
        else if (!step_hold_effective) fetch_valid <= 1'b1;
    end

    // While filling, the address presented is the reset vector (pc is held).
    assign imem_addr  = fetch_valid ? next_pc : pc;
    assign instruction = fetch_valid ? imem_instruction : 32'h0000_0013;

    logic        loader_imem_wr_en;
    logic [31:0] loader_imem_wr_addr;
    logic [31:0] loader_imem_wr_data;
    logic        loader_dmem_wr_en;
    logic [31:0] loader_dmem_wr_addr;
    logic [31:0] loader_dmem_wr_data;

    program_loader #(
        .IMEM_DEPTH (IMEM_DEPTH),
        .DMEM_DEPTH (DMEM_DEPTH)
    ) u_loader (
        .clk          (clk_cpu),
        .rst_n        (rst_n_cpu),
        .step_hold    (step_hold_effective),
        .prog_sel     (sw[3:0]),
        .key_load     (key_load),
        .load_done    (),
        .imem_wr_addr (loader_imem_wr_addr),
        .imem_wr_data (loader_imem_wr_data),
        .imem_wr_en   (loader_imem_wr_en),
        .dmem_wr_addr (loader_dmem_wr_addr),
        .dmem_wr_data (loader_dmem_wr_data),
        .dmem_wr_en   (loader_dmem_wr_en)
    );

    instruction_memory #(
        .IMEM_DEPTH (IMEM_DEPTH)
    ) u_imem (
        .clk         (clk_cpu),
        .fetch_en    (~div_busy & ~step_hold_effective),
        .next_pc     (imem_addr),
        .instruction (imem_instruction),
        .wr_en       (loader_imem_wr_en),
        .wr_addr     (loader_imem_wr_addr),
        .wr_data     (loader_imem_wr_data)
    );

    control_unit u_cu (
        .opcode         (opcode),
        .funct3         (funct3),
        .funct7         (funct7),
        .instr_31_20    (instr_31_20),
        .ru_wr          (ru_wr),
        .imm_src        (imm_src),
        .alua_src       (alua_src),
        .alub_src       (alub_src),
        .alu_op         (alu_op),
        .br_op          (br_op),
        .dm_wr          (dm_wr),
        .dm_ctrl        (dm_ctrl),
        .ru_data_wr_src (ru_data_wr_src),
        .trap_entry     (trap_entry),
        .mret_exec      (mret_exec),
        .csr_addr       (csr_addr),
        .csr_wr         (csr_wr_raw),
        .csr_op         (csr_op),
        .csr_imm        (csr_imm)
    );

    register_file u_rf (
        .clk      (clk_cpu),
        .rst      (~rst_n_cpu),     // register_file uses active-high synchronous rst
        .rs1_addr (rs1_addr),
        .rs2_addr (rs2_addr),
        .rd_addr  (rd_addr),
        .rd_data  (rd_data),
        .wr_en    (wr_en_gated & ~step_hold_effective),  // gated - not ru_wr directly (ADR 023)
        .rs1_data (rs1_data),
        .rs2_data (rs2_data),
        .dbg_regs (rf_dbg_regs)
    );

    imm_gen u_imm (
        .instruction (instruction),
        .imm_src     (imm_src),
        .imm_out     (imm_out)
    );

    branch_unit u_bu (
        .rs1_data    (rs1_data),
        .rs2_data    (rs2_data),
        .br_op       (br_op),
        .branch      (branch),
        .mask_pc_lsb (mask_pc_lsb)
    );

    alu_rv32im u_alu (
        .clk      (clk_cpu),
        .rst_n    (rst_n_cpu),
        .hold     (step_hold_effective),   // the divider is frozen with the processor
        .a        (alu_a),
        .b        (alu_b),
        .alu_op   (alu_op),
        .alu_res  (alu_res),
        .alu_sum  (alu_sum),
        .div_busy (div_busy),
        .div_done (div_done)
    );

    logic [3:0]  dmem_dbg_wr_be;
    logic [31:0] dmem_dbg_wr_data;

    data_memory #(
        .DMEM_DEPTH (DMEM_DEPTH)
    ) u_dmem (
        .clk           (clk_cpu),
        .addr          (alu_sum),
        .wr_data       (rs2_data),
        .dm_wr         (dm_wr),
        .dm_ctrl       (dm_ctrl),
        .rd_data       (dm_rd_data),
        .dbg_wr_be     (dmem_dbg_wr_be),
        .dbg_wr_data   (dmem_dbg_wr_data),
        .wr_en_loader  (loader_dmem_wr_en),
        .wr_addr_loader(loader_dmem_wr_addr),
        .wr_data_loader(loader_dmem_wr_data)
    );

    // ADR 027: CSR register file with trap logic
    csr_file u_csr (
        .clk         (clk_cpu),
        .rst_n       (rst_n_cpu),
        .csr_addr    (csr_addr),
        .csr_wdata   (csr_wdata),
        .csr_wr      (csr_wr & ~step_hold_effective),
        .csr_op      (csr_op),
        .csr_rdata   (csr_rdata),
        .trap_entry  (trap_entry),
        .trap_pc     (pc),            // mepc = PC of the trapping instruction
        .mret_exec   (mret_exec),
        .trap_target (trap_target),
        .mepc_value  (mepc_value)
    );

    seven_segment u_seven_seg0 (
        .val     (instruction[3:0]), // Display opcode[3:0] on 7-segment
        .display (seven_seg_display0)
    );

    seven_segment u_seven_seg1 (
        .val     (instruction[7:4]), 
        .display (seven_seg_display1)
    );

    seven_segment u_seven_seg2 (
        .val     (instruction[11:8]),
        .display (seven_seg_display2)
    );

    seven_segment u_seven_seg3 (
        .val     (instruction[15:12]),
        .display (seven_seg_display3)
    );

    seven_segment u_seven_seg4 (
        .val     (instruction[19:16]),
        .display (seven_seg_display4)
    );

    seven_segment u_seven_seg5 (
        .val     (instruction[23:20]),
        .display (seven_seg_display5)
    );

    // VGA visualization (Objective 4)
    logic        vga_pixel_clk;
    logic        pll_locked;
    logic [12:0] vmem_wr_addr;
    logic [15:0] vmem_wr_data;
    logic        vmem_wr_en;

    // Pixel clock PLL: 50 MHz --> 74.25 MHz (720p60)
    vga_pll u_vga_pll (
        .clk_in  (clk),
        .rst_in  (~rst_n),
        .clk_out (vga_pixel_clk),
        .locked  (pll_locked)
    );

    // VGA timing generator (sync only, 1280x720 @ 60 Hz)
    logic [10:0] vga_hcount;
    logic [9:0]  vga_vcount;
    logic        vga_video_on;

    // System reset synchronized into the pixel-clock domain.  The controller
    // uses a synchronous reset, so the counters start from a known state.
    logic [1:0]  vga_rst_sync;
    logic        vga_rst;

    always_ff @(posedge vga_pixel_clk) begin
        vga_rst_sync <= {vga_rst_sync[0], ~rst_n};
    end

    assign vga_rst = vga_rst_sync[1];

    vga_controller_1280x720 u_vga (
        .clk      (vga_pixel_clk),
        .reset    (vga_rst),
        .hsync    (vga_hsync),
        .vsync    (vga_vsync),
        .hcount   (vga_hcount),
        .vcount   (vga_vcount),
        .video_on (vga_video_on)
    );

    assign vga_clock   = vga_pixel_clk;
    assign vga_blank_n = vga_video_on;
    assign vga_sync_n  = 1'b0;

    // -----------------------------------------------------------------
    // Text-mode address generator:
    //   char_row = vcount / 16   (16 pixel rows per text line)
    //   char_col = hcount / 8    (8 pixel columns per character)
    //   mem_addr = char_row * 160 + char_col
    // -----------------------------------------------------------------
    logic [12:0] vmem_rd_addr;
    logic [13:0] vmem_char_addr;

    assign vmem_char_addr = ({8'd0, vga_vcount[9:4]} * 14'd160) + {6'd0, vga_hcount[10:3]};

    // Blanking addresses rows past the 7200-cell framebuffer; M10K reads
    // outside the array are undefined, so fold them back to a valid cell.
    assign vmem_rd_addr = (vmem_char_addr >= 14'd7200) ? 13'd0 : vmem_char_addr[12:0];

    // Single-clock dual-port video memory (M10K) - both ports on pixel clock.
    // The screen_writer runs in the VGA domain so writes are synchronous.
    logic [15:0] vmem_rd_data;
    video_memory u_vmem (
        .clk      (vga_pixel_clk),
        .wr_en    (vmem_wr_en),
        .wr_addr  (vmem_wr_addr),
        .wr_data  (vmem_wr_data),
        .rd_addr  (vmem_rd_addr),
        .rd_data  (vmem_rd_data)
    );

    // -----------------------------------------------------------------
    // VGA text-mode pixel generator (font ROM + character buffer)
    // -----------------------------------------------------------------
    vga_text_mode u_text_mode (
        .clk        (vga_pixel_clk),
        .reset      (vga_rst),
        .hcount     (vga_hcount),
        .vcount     (vga_vcount),
        .video_on   (vga_video_on),
        .char_data  (vmem_rd_data),
        .vga_r      (vga_r),
        .vga_g      (vga_g),
        .vga_b      (vga_b)
    );

    // Round-robin screen writer: one character per pixel clock cycle, one
    // group per cycle.  A cell is rewritten once per full rotation of the
    // groups - far faster than the VGA frame rate.
    screen_writer_single_cycle #(
        .DMEM_DEPTH (DMEM_DEPTH),
        .IMEM_DEPTH (IMEM_DEPTH)
    ) u_writer (
        .clk          (vga_pixel_clk),
        .rst_n        (~vga_rst),
        .pc           (pc),
        .instruction  (instruction),
        .next_pc      (pc_plus4),
        .branch       (branch),
        .rs1_addr     (rs1_addr),
        .rs2_addr     (rs2_addr),
        .rd_addr      (rd_addr),
        .rs1_data     (rs1_data),
        .rs2_data     (rs2_data),
        .imm_out      (imm_out),
        .imm_src      (imm_src),
        .opcode       (opcode),
        .funct3       (funct3),
        .funct7       (funct7),
        .ru_wr        (ru_wr),
        .ru_data_wr_src (ru_data_wr_src),
        .alu_op       (alu_op),
        .br_op        (br_op),
        .alua_src     (alua_src),
        .alub_src     (alub_src),
        .dm_ctrl      (dm_ctrl),
        .dm_wr        (dm_wr),
        .alu_a        (alu_a),
        .alu_b        (alu_b),
        .alu_res      (alu_res),
        .dm_addr      (alu_sum),          // alias: dm_addr = alu_sum
        .dm_wdata     (dm_wdata),
        .dm_rdata     (dm_rd_data),
        .data_wr      (rd_data),          // alias for ru_data_wr_src display
        .cycle_count  (cycle_count),
        .cycles_at_done (cycles_at_done),
        .instr_at_done  (instr_at_done),
        .halted       (program_done),
        .reg_values   (rf_dbg_regs),
        .imem_rd_addr (imem_shadow_rd_addr),
        .imem_rd_data (imem_shadow_rd_data),
        .dmem_rd_addr (dmem_shadow_rd_addr),
        .dmem_rd_data (dmem_shadow_rd_data),
        .vmem_wr_en   (vmem_wr_en),
        .vmem_wr_addr (vmem_wr_addr),
        .vmem_wr_data (vmem_wr_data)
    );

    // -----------------------------------------------------------------
    // Console shadows: copies of the program and data memories that the
    // VGA console reads.  The write port of the data shadow lives in the
    // processor clock domain and is driven by the very same signals as the
    // CPU's data memory, so the mirror holds exactly what the CPU's memory
    // holds.  The read ports live in the VGA clock domain.
    // -----------------------------------------------------------------
    logic [31:0] dmem_shadow_rd_data;
    logic [31:0] imem_shadow_rd_data;
    // The screen writer walks the memories; it drives the read addresses.
    logic [31:0] dmem_shadow_rd_addr;
    logic [31:0] imem_shadow_rd_addr;

    vga_mem_shadow #(.DEPTH(DMEM_DEPTH)) u_dmem_shadow (
        .wr_clk (clk_cpu),
        .wr_en  (dm_wr),
        .wr_addr(alu_sum),
        .wr_data(dmem_dbg_wr_data),
        .wr_be  (dmem_dbg_wr_be),
        .rd_clk (vga_pixel_clk),
        .rd_addr(dmem_shadow_rd_addr),
        .rd_data(dmem_shadow_rd_data)
    );

    vga_rom_shadow #(.DEPTH(IMEM_DEPTH)) u_imem_shadow (
        .wr_clk (clk_cpu),
        .wr_en  (loader_imem_wr_en),
        .wr_addr(loader_imem_wr_addr),
        .wr_data(loader_imem_wr_data),
        .rd_clk (vga_pixel_clk),
        .rd_addr(imem_shadow_rd_addr),
        .rd_data(imem_shadow_rd_data)
    );

endmodule
